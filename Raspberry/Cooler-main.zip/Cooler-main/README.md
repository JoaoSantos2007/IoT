# Cooler
 arquivo .py para ligar o cooler do raspberry pi quando tiver uma temperatura elevada
